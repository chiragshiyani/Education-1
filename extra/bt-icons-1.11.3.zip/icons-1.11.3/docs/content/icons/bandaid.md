---
title: Bandaid
categories:
  - Real World
tags:
  - bandage
  - health
---
