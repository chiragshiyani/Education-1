---
title: Braces asterisk
categories:
  - Typography
tags:
  - text
  - type
  - code
  - developer
  - development
  - software
added: 1.10.0
---
