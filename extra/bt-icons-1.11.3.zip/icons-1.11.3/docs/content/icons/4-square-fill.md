---
title: 4 square fill
categories:
  - Shapes
tags:
  - number
  - numeral
---
