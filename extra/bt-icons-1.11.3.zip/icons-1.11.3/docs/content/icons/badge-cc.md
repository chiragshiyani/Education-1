---
title: Badge cc
categories:
  - Badges
tags:
  - "closed captioning"
---
